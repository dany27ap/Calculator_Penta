package com.dlegacy.calculator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class WriteInFile {
    private String path;
    private String exp;
    private int result;

    public WriteInFile(String path, String exp, int result){
        this.exp = exp;
        this.path = path;
        this.result = result;
    }

    public void writeToFile() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(path, true));
        writer.append(' ');
        writer.newLine();
        writer.append(exp + " = " + result);

        writer.close();
    }
}
