package com.dlegacy.calculator;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Stack;

public class ExpParser {
    public static int result(ArrayList<String> string){
        int rezultat = 0;
        int a, b;
        Stack<Integer> stiva = new Stack<>();
        for(int i = 0; i < string.size(); ++i){
            try{
                Integer.parseInt(string.get(i));
                stiva.push(Integer.parseInt(string.get(i)));
            } catch (NumberFormatException ex){
                b = stiva.pop();
                a = stiva.pop();
                switch (string.get(i)) {
                    case "+":
                        rezultat = a+b;
                        break;
                    case "-":
                        rezultat = a-b;
                        break;
                    case "*":
                        rezultat = a*b;
                        break;
                    case "/":
                        rezultat = a/b;
                        break;
                }
                stiva.push(rezultat);
            }
        }
        if(!stiva.empty()){
            rezultat = stiva.pop();
        }
        return rezultat;
    }
}
